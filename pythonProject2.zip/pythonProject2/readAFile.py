'''my_file = open("myfile.txt", 'r')

print(my_file.read())
my_file.close()
print('#'*20)
my_file = open("myfile.txt", 'r')

print(my_file.readline())
print(my_file.readline())
print(my_file.readline()) #or put it in a for loop to read each line
my_file.close()'''

a = {}
names = input('enter ur name').split()
age =[]
for i in range(len(names)):
    age.append(int(input('age')))
for key, value in zip(names, age):
    a[key] = value
print(a)
