class Employee(object):
    def __init__(self,name,gender, employeeId, city, location, department, employeeType, band, pfNum, bankAccNum, ctc, salarySlip):
        self.name = name
        self.gender = gender
        self.employeeId = employeeId
        self.city = city
        self.location = location
        self.department = department
        self.employeeType = employeeType
        self.band = band
        self.pfNum = pfNum
        self.bankAccNum = bankAccNum
        self.ctc = ctc
        self.salarySlip = salarySlip

    def get_name(self):
        return self.name

    def get_gender(self):
        return self.gender

    def get_employee_id(self):
        return self.employeeId

    def get_city(self):
        return self.city

    def get_location(self):
        return self.location

    def get_department(self):
        return self.department

    def get_employee_type(self):
        return self.employeeType

    def get_band(self):
        return self.band

    def get_pf_num(self):
        return self.pfNum

    def get_bank_acc(self):
        return self.bankAccNum

    def get_ctc(self):
        return self.ctc

    def salary_slip(self):
        return self.salarySlip

def enter_employee_details():
    name = input("Enter Employee Name: ")
    gender = input("Enter Employee Gender:        ")
    employeeId = int(input("Enter EmployeeId: "))
    city = input("Please enter Employee City: ")
    location = input("Enter Employee Location: ")
    department = input("Enter Employee Department: ")
    employeeType = input("Enter Employee Type: ")
    band = input("Enter Band: ")
    pfNum = int(input("Enter PF Number: "))
    bankAccNum = int(input("Enter bank Acc Num: "))
    ctc = int(input("Enter ctc "))
    salarySlip = {"08-2022":{
        "basic_salary": 60000,
        "variable_pay": 30000,
        "provident_fund": 5000,
        "other_allowance": 5000,
        "income_tax": 10000,
        "mess_bill": 100,
        "net_pay": 89900,
        "gross_pay": 100000,
            },
        "09-2022":
            {"basic_salary": 60000,
             "variable_pay": 30000,
             "provident_fund": 5000,
             "other_allowance": 5000,
             "income_tax": 10000,
             "mess_bill": 100,
             "net_pay": 89900,
             "gross_pay": 100000,
            }}
    return Employee(name,gender, employeeId, city, location, department, employeeType, band, pfNum, bankAccNum, ctc, salarySlip)

def search_employee(employees):
    firstName = input("Enter Employees name: ")
    for employee in employees:
        if firstName in employee.get_name():
            print(employee)
        else:
            print("Employee not found..!! ")

def print_all_employees(employees):
    print("Showing all Employees: ")
    for employee in employees:
        print(employee)

def remove_employee(employee):
    print("Remove Employee")
    firstName = input("Please enter firstName:   ")
    for i in employee:
        if firstName in employee:
            employee.remove(i)
            break

def choices():
    print("What do you want to do:-")
    print("1. New Employee.")
    print("2. Search Employee.")
    print("3. Print all Employees.")
    print("4. Remove Employee.")
    print("5. Exit.")

def main():
    option = 0
    employees = []
    while True:
        choices()
        option = input()
        if option == "1":
            employees.append(enter_employee_details())
        elif option == "2":
            search_employee(employees)
        elif option == "3":
            print_all_employees(employees)
        elif option == "4":
            remove_employee(employees)
        elif option == "5":
            print("Exit")
            break

if __name__=='__main__':
    main()