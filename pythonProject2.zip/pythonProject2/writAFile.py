my_list = ['kantara', '3idiots', 'kgf', 'familyMan']

my_file = open('myfile.txt', 'w')

for item in my_list:
    my_file.write(str(item)+ '\n')
my_file.close()