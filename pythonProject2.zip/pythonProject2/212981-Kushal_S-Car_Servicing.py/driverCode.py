from car import Car
from serviceStation import ServiceStation

my_obj = Car()
my_ser = ServiceStation('Kushal','Bangalore',1234, 'Tata')
new_car = []


def create_car():
    print('-----Creating New Car-----')
    car_comp_name = input("Enter the company of your car")
    car_model = input("Enter the model of your car")
    year_of_pur = int(input("Enter the year of purchase"))
    num_of_owners = int(input("Enter the number of owners"))
    car_reg_num = int(input("Enter the car registration number"))
    print("-----New car is added-----")


def print_car_details():
    new_list_of_car = Car()
    print(new_list_of_car)


def update_insurance():
    print("Insurance premium amount is:\t\t", my_obj.insurance_pre_amount_paid)
    print("Insurance number is:\t\t\t\t", my_obj.insurance_num)
    print("Insurance type is(1st,2nd or 3rd):\t", my_obj.insurance_type)
    print("Insurance expiry date is:\t\t\t", my_obj.insurance_exp_date)

    date = int(input("Enter the year:"))
    if date < my_obj.insurance_exp_date:
        print("Insurance is not yet expired")
    elif date == my_obj.insurance_exp_date:
        print("Insurance is going to expire soon..!!")
    else:
        print("Insurance is expired")
        my_obj.insurance_exp_date = date
        print("Updated insurance date is:", my_obj.insurance_exp_date)


def drop_car_to_service():
    print("Adding car registration num to service:",my_ser.car_reg_num)


def pick_up_car_from_service():
    print("Following car is serviced:",my_ser.car_name)


def choices():
    print('------XXX------')
    print("What do you want to do:-")
    print("1. Create car.")
    print("2. Print all car details.")
    print("3. Update insurance.")
    print("4. Drop car to service.")
    print("5. Pick up car from service.")
    print("6. Exit.")


def main():
    while True:
        choices()
        option = input()
        if option == '1':
            create_car()
        elif option == '2':
            print_car_details()
        elif option == '3':
            update_insurance()
        elif option == '4':
            drop_car_to_service()
        elif option == '5':
            pick_up_car_from_service()
        elif option == '6':
            print("------Exit-----")
            break


if __name__ == '__main__':
    main()