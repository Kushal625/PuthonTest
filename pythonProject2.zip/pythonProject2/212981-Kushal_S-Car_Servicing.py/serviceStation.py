from car import Car


class ServiceStation:
    def __init__(self, Name, Address, car_reg_num, car_name):
        self.Name = Name
        self.Address = Address
        self.car_reg_num = car_reg_num
        self.car_name = car_name


def service_car():
    a = ServiceStation('kushal', 'Bangalore', 1234, 'Tata')
    b = a.car_reg_num
    print("Car registration number :", b)
    x = Car().last_service_data['Amount']
    print("Service cost is :", x)


if __name__ == '__main__':
    service_car()
