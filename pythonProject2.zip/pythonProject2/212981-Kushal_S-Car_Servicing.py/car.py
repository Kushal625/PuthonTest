from objprint import add_objprint


@add_objprint
class Car:
    def __init__(self):
        self.car_company_name = 'Tata'
        self.car_model = 'Tiago'
        self.year_of_purchase = 2022
        self.num_of_owners = 1
        self.car_reg_num = 1234
        self.last_service_data = {"Odo": 1015, "Issues": "Low tire pressure", "Date": "19/06/2016", "Amount": 810}
        self.odometer_reading = 100
        self.insurance_num = 123456789
        self.insurance_exp_date = 2021
        self.insurance_type = 1
        self.insurance_pre_amount_paid = 5000
        self.chassis_num = 78384
        self.engine_num = 13323


def car_reg_num(self):
    return self.car_reg_num
