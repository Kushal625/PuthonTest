import new

class Employer(object):

    def __init__(self,name,locations,bands,departments):
        self.companyName = name
        self.locations = locations
        self.bands = bands
        self.departments = departments

my_file = open("new.py",'r')


