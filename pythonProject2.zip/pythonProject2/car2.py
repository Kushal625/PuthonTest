#create car
#To take input from the user

from objprint import add_objprint

@add_objprint()
class Car:
    def __init__(self,car_comp_name,car_model,year_of_pur,num_of_owners,car_reg_num):
        self.car_company_name = car_comp_name
        self.car_model = car_model
        self.year_of_purchase = year_of_pur
        self.num_of_owners = num_of_owners
        self.car_reg_num = car_reg_num
        '''
        self.last_service_data = {"Odo": 1015, "Issues": "Low tire pressure", "Date": "19/06/2016", "Amount": 810}
        self.odometer_reading = odometer_reading
        self.insurance_num = insurance_num
        self.insurance_exp_date = insurance_exp_date
        self.insurance_type = insurance_type
        self.insurance_pre_amount_paid = insurance_pre_amount_paid
        self.chassis_num = chassis_num
        self.engine_num = engine_num'''


def main():
    car_comp_name = input("Enter the company of your car")
    car_model = input("Enter the model of your car")
    year_of_pur = int(input("Enter the year of purchase"))
    num_of_owners = int(input("Enter the number of owners"))
    car_reg_num = int(input("Enter the car registration number"))
    return Car(car_comp_name,car_model,year_of_pur,num_of_owners,car_reg_num)


if __name__=='__main__':
    print(main())