import time
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys


s = Service("C:\Drivers\chromedriver.exe")
driver = webdriver.Chrome(service=s)
driver.get("https://www.google.co.in/")
driver.maximize_window()
driver.implicitly_wait(25)
search = driver.find_element(By.XPATH,"/html/body/div[1]/div[3]/form/div[1]/div[1]/div[1]/div/div[2]/input")
search.send_keys("flipkart")
search.send_keys(Keys.ENTER)

driver.find_element(By.XPATH,"/html/body/div[7]/div/div[11]/div[1]/div[2]/div[2]/div/div/div[1]/div/div/div/div/div/div/div/div[1]/a").click()

#driver.find_element(By.XPATH,"/html/body/div[2]/div/div/div/div/div[2]/div/form/div[4]/a").click()

#Login
'''driver.find_element(By.XPATH,"/html/body/div[2]/div/div/div/div/div[2]/div/form/div[1]/input").click()
driver.find_element(By.XPATH,"/html/body/div[2]/div/div/div/div/div[2]/div/form/div[1]/input").send_keys("7975817281")
driver.find_element(By.XPATH,"/html/body/div[2]/div/div/div/div/div[2]/div/form/div[3]/button").click()'''
driver.find_element(By.XPATH,"/html/body/div[2]/div/div/button").click()

#To search New mobiles
driver.find_element(By.XPATH,"//*[@id='container']/div/div[1]/div[1]/div[2]/div[2]/form/div/div/input").click()
a = driver.find_element(By.XPATH,"//*[@id='container']/div/div[1]/div[1]/div[2]/div[2]/form/div/div/input")
a.send_keys("new mobile")
a.send_keys(Keys.ENTER)
text1 = driver.find_element(By.XPATH,"//*[@id='container']/div/div[3]/div[1]/div[2]/div[2]/div/div/div/a/div[2]/div[1]").text
print(text1)

#Mens Wear
driver.find_element(By.XPATH,"//*[@id='container']/div/div[2]/div/div/span[3]").click()
driver.find_element(By.XPATH,"//*[@id='container']/div/div[2]/div/div/div/div[2]/a[3]").click()

#To check discount
driver.find_element(By.XPATH,"//*[@id='container']/div/div[3]/div[1]/div[1]/div/div/div/section[4]/div/div").click()
driver.find_element(By.XPATH,"//*[@id='container']/div/div[3]/div[1]/div[1]/div/div/div/section[4]/div[2]/div/div[1]/div/label/div[1]").click()

#T-Shirt
driver.find_element(By.XPATH,"//*[@id='container']/div/div[3]/div/div[2]/div[2]/div/div[3]/div/a/div[1]/div/div/div/img").click()
new_tab = driver.window_handles[1]
driver.switch_to.window(new_tab)
b = driver.find_element(By.XPATH,"//*[@id='container']/div/div[3]/div[1]/div[2]/div[2]").text
print('-------------------')
print(b)

#To scroll down window and select T-Shirt size
driver.execute_script("window.scrollTo(0,550)")
driver.find_element(By.XPATH,"//*[@id='swatch-1-size']/a").click()


time.sleep(10)